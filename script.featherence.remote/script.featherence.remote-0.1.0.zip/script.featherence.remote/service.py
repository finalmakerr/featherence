import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

from variables import *
from modules import *

xbmc.sleep(2000)

mode5('')
