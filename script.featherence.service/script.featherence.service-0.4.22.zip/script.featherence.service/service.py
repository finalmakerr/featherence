#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

from variables import *
from modules import *

xbmc.sleep(100)

mode5('', admin, 'demon', '')
#mode3('', admin, 'sdarot', '')