import xbmc, xbmcgui
import os, sys
import subprocess
import xbmcaddon

from variables import *
from modules import *

xbmc.sleep(200)

mode5('', admin, 'demon', '')
