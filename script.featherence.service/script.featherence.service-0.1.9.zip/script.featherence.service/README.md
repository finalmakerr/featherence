![](http://i.imgur.com/zfdrpSG.png)

# **Features:**

* This addon is a core for every Featherence's addon.
* Wide range of tools to be used from within Kodi.
* Wide range of modules to be used by addons developers.
* Widget to be used on any supported skin.
* IR remote control for OpenELEC os.
* Please note that many modules are being used in Featherence skin and are not possible on others skins yet.


# **Available scripts commands:**

```
SOFT-RESTART (Terminal supported)
RunScript(script.featherence.service,,?mode=50)
```

```
RESTART (Terminal supported)
RunScript(script.featherence.service,,?mode=51)
```

```
SUSPEND (Terminal supported)
RunScript(script.featherence.service,,?mode=52)
```

```
POWEROFF (Terminal supported)
RunScript(script.featherence.service,,?mode=53)
```

```
QUIT (Terminal supported)
RunScript(script.featherence.service,,?mode=54)
```

```
LAUNCH EXTENDEDINFO MOVIES INFO
RunScript(script.featherence.service,,?mode=70&amp;value=0)
```

```
LAUNCH EXTENDEDINFO TVSHOWS INFO
RunScript(script.featherence.service,,?mode=70&amp;value=1)
```

```
LAUNCH EXTENDEDINFO ACTORS INFO
RunScript(script.featherence.service,,?mode=70&amp;value=3)
```

```
LAUNCH EXTENDEDINFO DIRECTOR INFO
RunScript(script.featherence.service,,?mode=70&amp;value=4)
```

```
OPEN CUSTOM DIALOG TEXT VIEWER
RunScript(script.featherence.service,,?mode=31&amp;value=header&amp;value2=message)
```

```
READ FROM FILE AND DISPLAY
RunScript(script.featherence.service,,?mode=31&amp;value=header&amp;value2=message&amp;value3=filepath)
```

# **Integrating Widget:**
* [Match Skin Widgets Property](http://kodi.wiki/view/Add-on:Skin_Widgets)

```
Run Widget Recent Movie
<onclick>RunScript(script.featherence.service,,?mode=24&amp;value=RecentMovie.1)</onclick>
```

```
Run Widget Random Movie Trailer Full screen
<onclick>RunScript(script.featherence.service,,?mode=24&amp;value=RecentMovie.1&amp;value2=trailers)</onclick>
```

```
Run Widget Random Movie Trailer
<onclick>RunScript(script.featherence.service,,?mode=24&amp;value=RecentMovie.10&amp;value2=trailers2)</onclick>
```

```
Run Widget Recent Episode
<onclick>RunScript(script.featherence.service,,?mode=24&amp;value=RecentEpisode.1)</onclick>
```

```
Run Widget Recommended Episode
<onclick>RunScript(script.featherence.service,,?mode=24&amp;value=RecommendedEpisode.10)</onclick>
```

```
Auto Refresh Widget contents upon end of Movie / Episode
VideoFullScreen.xml
<onload condition="IsEmpty(Window(home).Property(mode10))">RunScript(script.featherence.service,,?mode=10)</onload>
```

```
Refresh Widget
RunScript(script.featherence.service,,?mode=23)
```

```
PLAY RANDOM TRAILERS
RunScript(script.featherence.service,,?mode=25)
```

# **Create your own plugin:**
* **modules.py:**
  * **addDir:**
	```
	addDir form
	addDir('<name>','<url>',<mode number>,'<iconimage>','<description>','<optional>',"<viewtype>", '<fanart>')
	```
	
	```
	PLAY YOUTUBE VIDEO
	METHOD 1: MODE 4 | URL = text
	METHOD 2: MODE 5/6/17 | URL = &youtube_id=text
	```
	
	```
	YOUTUBE PLAYLIST
	PLAY: MODE 12 | URL = text
	OPEN: MODE 13 | URL = text
	FEATHERENCE: MODE 5/6/17 | URL = &youtube_pl=text
	```
	
	```
	YOUTUBE CHANNEL
	OPEN: MODE 9 | URL = text
	FEATHERENCE: MODE 5/6/17 | URL = &youtube_ch=text
	TIP: You may add '/playlists' after that channel id!
	```
	
	```
	SEARCH YOUTUBE
	OPEN: MODE 3 | URL = text
	FEATHERENCE: MODE 5/6/17 | URL = &youtube_se=text
	```
	
	```
	READ LINE BY LINE FROM FILE AND SEARCH IN YOUTUBE
	PLAY ALL: MODE 2 | URL = <file path>
	TIP: os.path.join(addonPath, 'resources', 'templates2', '')
	addonPath = current addon
	```
	
	```
	PLAY DIALYMOTION VIDEO
	FEATHERENCE: MODE 5/6/17 | URL = &dailymotion_id=text
	```
	
	```
	SDAROT TV VIDEO
	FEATHERENCE: MODE 5/6/17 | URL = &sdarot=text
	TIP: use ctrl+shift+P on the preferred location!
	```
	
	```
	WALLA NEW VIDEO
	FEATHERENCE: MODE 5/6/17 | URL = &wallaNew=text
	TIP: use ctrl+shift+P on the preferred location!
	```
	
	```
	ANY URLS
	OPEN: MODE 8 | URL = <file path>
	PLAY: MODE 10 | URL = <file path>
	TIP: use ctrl+shift+P on the preferred location!
	```
	
	```
	GET ADDON INFO
	ADDON = <ADDON ID>
	thumb, fanart, summary, description, plot = getAddonInfo(addon)
	```
	
	```
	GET INFO FROM YOUTUBE
	OPTIONAL = 'getAPIdata=<text>'
	text = &youtube_se=#Lion
	in that addDir put 'getAPIdata' in any of those:
		name, iconimage, desc, fanart
	```
	
	```
	SHOW ALL
	METHOD 1: MODE 6 | URL = <anything with '&xxx=text'>
	TIP: URL must be a list []
	```
	
	```
	PLAY ALL
	METHOD 1: MODE 5 | URL = <anything with '&xxx=text'>
	TIP: URL must be a list []
	```
	
	```
	TVMODE
	METHOD 1: MODE 17 | URL = <anything with '&xxx=text'>
	TIP: URL must be a list []
	```
	
# **Links:**

* [Facebook](https://www.facebook.com/groups/featherence/)
* [YouTube](https://www.youtube.com/user/finalmakerr)
* [Featherence Repository](https://github.com/finalmakerr/featherence/raw/master/repository.featherence/repository.featherence-1.1.0.zip)
