﻿# -*- coding: UTF-8 -*-
import sys, os

from variables import *
from shared_variables import *
from shared_modules import *
from modules import *
from modules2 import *

if ( __name__ == "__main__" ):
    import resources.lib.launcher_plugin as plugin
    plugin.Main()
